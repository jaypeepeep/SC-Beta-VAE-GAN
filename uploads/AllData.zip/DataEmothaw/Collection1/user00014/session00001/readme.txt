
on corrige user00014_hw2 car point parasite